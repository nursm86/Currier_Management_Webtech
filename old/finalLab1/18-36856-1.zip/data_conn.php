<?php
    $servername = "localhost";
    $username = "root";
    $pass = "";
    $dbname = "lab";

    $conn = mysqli_connect($servername,$username,$pass,$dbname);

    function execute($query){
        global $servername,$username,$pass,$dbname,$conn;
        $result = mysqli_query($conn, $query);
    }

    function getResult($query){
        global $servername,$username,$pass,$dbname,$conn;
        $result = mysqli_query($conn, $query);
        return $result;
    }

    function getArray($query){
        $result = getResult($query);
        if(mysqli_num_rows($result)<2){
            return mysqli_fetch_assoc($result);
        }
        $data = array();
        while($row = mysqli_fetch_assoc($result)){
            $data[] = $row;
        }
        return $data;
    }
?>